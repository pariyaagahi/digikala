package com.example.digiBook;

import androidx.annotation.NonNull;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.example.digiBook.database.productsDbHelper;
import com.squareup.picasso.Picasso;

import static com.example.digiBook.database.productsDbHelper.PRODUCTS_KET_ID;

public class detailActivity extends BaseActivity {

    ImageView imageView;
    TextView title, description, cost;
    RatingBar ratingBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().setTitle("");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        init();
        Intent intent = getIntent();
        if (intent == null) {
            finish();
            return;
        }
        String titlee = intent.getStringExtra("title");
        String descriptionn = intent.getStringExtra("description");
        String costt = intent.getStringExtra("cost");
        String imageUrll = intent.getStringExtra("imageUrl");
        String stars=intent.getStringExtra("stars");
        String id=intent.getStringExtra("id");
        ratingBar=findViewById(R.id.rating);
        ratingBar.setRating(Float.parseFloat(stars));
        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                new productsDbHelper(detailActivity.this).updateStars(id,String.valueOf(rating));
            }
        });



        title.setText(String.valueOf(titlee));
        description.setText(String.valueOf(descriptionn));
        cost.setText(String.valueOf(costt));
        Picasso.get().load(imageUrll).into(imageView);


    }


    public void init() {
        title = findViewById(R.id.detailTitle);
        description = findViewById(R.id.detailDescription);
        cost = findViewById(R.id.detailCost);
        imageView = findViewById(R.id.detailImage);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
       getMenuInflater().inflate(R.menu.detail_activity_actionbar,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.action_back:
                finish();
            case R.id.kotobeMoshabeh:
                String address="https://www.digikala.com/";
                Intent intent=new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(address));
                startActivity(intent);
            case R.id.moghayeseMahsool:
                String add="https://www.digikala.com/";
                Intent intent1=new Intent();
                intent1.setAction(Intent.ACTION_VIEW);
                intent1.setData(Uri.parse(add));
                startActivity(intent1);

        }
        return super.onOptionsItemSelected(item);
    }

    public void call(View view) {
        String str="tel:09398805799";
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(str));
        startActivity(intent);
    }

    public void sms(View view) {
        String str="sms:09398805799";
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(str));
        startActivity(intent);
    }
}