package com.example.digiBook;

import android.app.AlertDialog;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class BaseActivity extends AppCompatActivity {
   WifiBroadCast wifiBroadCast;
    public static AlertDialog alertDialog=null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        wifiBroadCast=new WifiBroadCast();


       SharedPreferences sharedPreferences=getSharedPreferences(Const.SHARED_PREF_NAME_LOGIN , MODE_PRIVATE);
        if(sharedPreferences.contains(Const.SHARED_PREF_KEY_AUTHENTICATION))
        {
            boolean flag=sharedPreferences.getBoolean(Const.SHARED_PREF_KEY_AUTHENTICATION,false);
            if(!flag)
            {
                goToRegisterActivity();
            }
        }else
        {
            goToRegisterActivity();
       }

        SharedPreferences sharedPreferenceTheme=getSharedPreferences(Const.SHARED_PREF_NAME , MODE_PRIVATE);
        int themeValue = sharedPreferenceTheme.getInt(Const.SHARED_PREF_KEY_THEME, 0);
        if(themeValue!=0)
        {
            setTheme(themeValue);
        }
        SharedPreferences sharedPreferenceFont=getSharedPreferences(Const.SHARED_PREF_NAME , MODE_PRIVATE);
        int fontValue = sharedPreferenceFont.getInt(Const.SHARED_PREF_KEY_FONT,0);
        if (fontValue!=0)
        {
            setTheme(fontValue);
        }
        SharedPreferences sharedPreferenceTF =getSharedPreferences(Const.SHARED_PREF_NAME , MODE_PRIVATE);
        int bothValue = sharedPreferenceTF.getInt(Const.SHARED_PREF_KEY_BOTH_THEMES,0);
        if (fontValue!=0)
        {
            setTheme(bothValue);
        }

    }
    private void goToRegisterActivity()
    {
        Intent intent=new Intent(this,profile.class);
        startActivity(intent);
        finish();
    }

    @Override
  protected void onResume() {
       super.onResume();
       registerReceiver(wifiBroadCast,new IntentFilter(Const.ACTION_WIFI));
   }

    @Override
    protected void onStop() {
        super.onStop();
        unregisterReceiver(wifiBroadCast);
    }


    class WifiBroadCast extends BroadcastReceiver
    {
        public WifiBroadCast() {
            View alertDialogView = LayoutInflater.from(BaseActivity.this).inflate(R.layout.customize_alert_dialog,null);
            AlertDialog.Builder builder = new AlertDialog.Builder(BaseActivity.this);
            builder.setView(alertDialogView);
            builder.setCancelable(false);
            alertDialog= builder.create();
            alertDialog.show();
            Button wifi = alertDialog.findViewById(R.id.btnWifi);
            wifi.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent= new Intent(Settings.ACTION_WIFI_SETTINGS);
                    startActivity(intent);
                }
            });
            alertDialog.dismiss();
        }

        @Override
        public void onReceive(Context context, Intent intent) {

            WifiManager wifiManager= (WifiManager) getApplicationContext().getSystemService(Service.WIFI_SERVICE);

            if(wifiManager.isWifiEnabled())
            {
                alertDialog.dismiss();
            }else
            {
                alertDialog.show();
            }
        }
    }
}
