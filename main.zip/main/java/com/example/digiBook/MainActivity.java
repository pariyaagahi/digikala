package com.example.digiBook;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.RadioGroup;


import androidx.viewpager.widget.ViewPager;

import com.example.digiBook.adapter.customAdapter;
import com.example.digiBook.database.productsDbHelper;
import com.example.digiBook.entity.dbProduct;

import java.util.ArrayList;

public class MainActivity extends BaseActivity {

    productsDbHelper productsDbHelper;
    ListView listView;
    EditText etsearch;
    ViewPager mViewPager;
    GridView gridView;
    RadioGroup radioGroup;
    View tamasbama, darbarema, tanzimat, download, profile, home;
    int[] images = {R.drawable.slide1, R.drawable.slide2};
    ViewPagerAdapter mViewPagerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        customActionBar();

        productsDbHelper = new productsDbHelper(this);

        mViewPagerAdapter = new ViewPagerAdapter(MainActivity.this, images);

        mViewPager = (ViewPager) findViewById(R.id.viewPagerMain);
        mViewPager.setAdapter(mViewPagerAdapter);
        init();

        radioGroup=findViewById(R.id.RGmoratabsazi);
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int checkedId) {
                if (R.id.btnListView==checkedId){
                    listView.setVisibility(View.VISIBLE);
                    gridView.setVisibility(View.INVISIBLE);
                }
                else if (R.id.btnGridView==checkedId){
                    gridView.setVisibility(View.VISIBLE);
                    listView.setVisibility(View.INVISIBLE);

                }
            }
        });
    }


    @Override
    protected void onResume() {
        super.onResume();
        initListView();
        initGridView();
    }

    public void init() {

        listView = findViewById(R.id.mainlistView);
        gridView = findViewById(R.id.mainGridView);
        tamasbama=findViewById(R.id.tamasBama);
        darbarema=findViewById(R.id.darbareMa);
        tanzimat=findViewById(R.id.tanzimat);
        download=findViewById(R.id.download);
        profile=findViewById(R.id.profile);
        home=findViewById(R.id.home);


        tamasbama.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(MainActivity.this, tamasbama.class);
                startActivity(intent1);
            }
        });
        darbarema.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(MainActivity.this, darbarema.class);
                startActivity(intent2);
            }
        });
        tanzimat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent3 = new Intent(MainActivity.this, tanzimat.class);
                startActivity(intent3);
            }
        });
        download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent4 = new Intent(MainActivity.this, download.class);
                startActivity(intent4);
            }
        });
        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent5 = new Intent(MainActivity.this, profile.class);
                startActivity(intent5);
            }
        });

        home.setEnabled(false);

    }



    public void customActionBar() {
        View actionBarView = LayoutInflater.from(this).inflate(R.layout.actionbar_main_activity, null);
        getSupportActionBar().setCustomView(actionBarView);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setTitle("");
        etsearch = actionBarView.findViewById(R.id.etsearch);
        etsearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                ArrayList<dbProduct> data = new productsDbHelper(MainActivity.this).select(s.toString());
                customAdapter listViewAdapter = new customAdapter(MainActivity.this, data, R.layout.listview_item_layout);
                customAdapter gridViewAdapter = new customAdapter(MainActivity.this, data, R.layout.gridview_item_layout);
                listView.setAdapter(listViewAdapter);
                gridView.setAdapter(gridViewAdapter);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

    }



    public void initListView() {

        ArrayList<dbProduct> data = productsDbHelper.select();
        customAdapter adapter = new customAdapter(this, data, R.layout.listview_item_layout);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                dbProduct product = (dbProduct) parent.getItemAtPosition(position);
                Intent intent = new Intent(MainActivity.this, detailActivity.class);
                intent.putExtra("id",product.getId());
                intent.putExtra("title", product.getTitle());
                intent.putExtra("description", product.getDescription());
                intent.putExtra("cost", product.getCost());
                intent.putExtra("imageUrl", product.getImageUrl());
                intent.putExtra("stars",product.getStars());
                startActivity(intent);
            }
        });
    }

    public void initGridView() {
        ArrayList<dbProduct> data = productsDbHelper.select();
        customAdapter adapter = new customAdapter(this, data, R.layout.gridview_item_layout);
        gridView.setAdapter(adapter);

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                dbProduct product = (dbProduct) parent.getItemAtPosition(position);
                Intent intent = new Intent(MainActivity.this, detailActivity.class);
                intent.putExtra("id",product.getId());
                intent.putExtra("title", product.getTitle());
                intent.putExtra("description", product.getDescription());
                intent.putExtra("cost", product.getCost());
                intent.putExtra("imageUrl", product.getImageUrl());
                intent.putExtra("stars",product.getStars());
                startActivity(intent);
            }
        });

    }

}