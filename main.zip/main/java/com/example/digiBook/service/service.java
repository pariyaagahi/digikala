
package com.example.digiBook.service;


import android.app.IntentService;
import android.content.Intent;
import android.os.SystemClock;
import android.util.Log;

import androidx.annotation.Nullable;

import com.example.digiBook.Const;
import com.example.digiBook.api.digikalaApi;
import com.example.digiBook.database.musicsDbHelper;
import com.example.digiBook.database.productsDbHelper;
import com.example.digiBook.entity.dbProduct;
import com.example.digiBook.entity.music;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class service extends IntentService {

    boolean checkDB=false;

    public service() {
        super("service");
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {


        checkDB = new productsDbHelper(this).checkEmptyDB();
        if (!checkDB){

            Retrofit retrofit = new Retrofit.Builder()
                    .baseUrl(digikalaApi.BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create()).build();

            digikalaApi api = retrofit.create(digikalaApi.class);

            final Call<ArrayList<dbProduct>> request1 = api.getProducts();
            final Call<ArrayList<music>> request2 = api.getMusics();

            request1.enqueue(new Callback<ArrayList<dbProduct>>() {
                @Override
                public void onResponse(Call<ArrayList<dbProduct>> call, Response<ArrayList<dbProduct>> response) {
                    int code = response.code();
                    if (code == 200) {
                        ArrayList<dbProduct> products = response.body();
                        for (dbProduct item : products) {
                            productsDbHelper productsDbHelper = new productsDbHelper(service.this);
                            dbProduct product = new dbProduct(item.getId(),item.getTitle(), item.getCost(), item.getImageUrl(), item.getDescription(),item.getStars());
                            long result = productsDbHelper.insert(product);
                            if (result > -1) {
                                Log.e("products", "success");
                            }
                        }
                    }
                }

                @Override
                public void onFailure(Call<ArrayList<dbProduct>> call, Throwable t) {
                }
            });
            request2.enqueue(new Callback<ArrayList<music>>() {
                @Override
                public void onResponse(Call<ArrayList<music>> call, Response<ArrayList<music>> response) {
                    int code = response.code();
                    if (code == 200) {
                        ArrayList<music> musics = response.body();
                        for (music item : musics) {
                            musicsDbHelper musicsDbHelper = new musicsDbHelper(service.this);
                            music music = new music(item.getMusicName(), item.getSinger(), item.getImageUrl(),item.getMusicUrl());
                            long result = musicsDbHelper.insert(music);
                            if (result > -1) {
                                Log.e("musics", "success");
                            }

                        }
                    }
                }

                @Override
                public void onFailure(Call<ArrayList<music>> call, Throwable t) {
                }
            });

        }

        SystemClock.sleep(3000);

    sendBroadcast(new Intent(Const.ACTION_NAME));

    }
}
