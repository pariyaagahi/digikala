package com.example.digiBook.api;

import com.example.digiBook.entity.dbProduct;
import com.example.digiBook.entity.music;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.http.GET;

public interface digikalaApi {

    String BASE_URL="https://run.mocky.io";

    @GET("/v3/559c7f5a-9c6c-464a-9239-87bc5d7fb833")

    Call<ArrayList<dbProduct>> getProducts();


    @GET("/v3/5eb4742f-7759-48c8-b23f-c51e74aac98c")

    Call<ArrayList<music>> getMusics();

}
