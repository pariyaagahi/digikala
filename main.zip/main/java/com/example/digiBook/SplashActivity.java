package com.example.digiBook;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;

import com.example.digiBook.service.service;

public class SplashActivity extends BaseActivity {


    MyBroadCast myBroadCast;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
       getSupportActionBar().hide();
        setContentView(R.layout.activity_splash);


        myBroadCast=new MyBroadCast();
    }

    @Override
    protected void onStart() {
        super.onStart();
        registerReceiver(myBroadCast , new IntentFilter(Const.ACTION_NAME));
    }

    @Override
    protected void onResume() {
        super.onResume();
            Intent intent=new Intent(this , service.class);
            startService(intent);


    }
    @Override
    protected void onStop() {
        super.onStop();
        unregisterReceiver(myBroadCast);
    }

    class MyBroadCast extends BroadcastReceiver
    {

        @Override
        public void onReceive(Context context, Intent intent) {

            Intent newIntent=new Intent(SplashActivity.this, MainActivity.class);
            startActivity(newIntent);
            finish();


        }
    }
}