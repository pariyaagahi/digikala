package com.example.digiBook;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import static com.example.digiBook.Const.SHARED_PREF_NAME_LOGIN;

public class profile extends AppCompatActivity {

    View tamasbama, darbarema, tanzimat, download, profile, home;
    EditText etUserName,etPassword,etPhoneNumber,etEmail;
    LinearLayout layoutBellow;
    Button taeed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setTitle("ثبت نام / ورود");
        setContentView(R.layout.activity_profile);
        init();

        if (etUserName.getText().toString().isEmpty()){
            layoutBellow.setVisibility(View.INVISIBLE);
        }
    }


    public void init() {

        tamasbama=findViewById(R.id.tamasBama);
        darbarema=findViewById(R.id.darbareMa);
        tanzimat=findViewById(R.id.tanzimat);
        download=findViewById(R.id.download);
        profile=findViewById(R.id.profile);
        home=findViewById(R.id.home);
        layoutBellow=findViewById(R.id.layoutbellow);

        etUserName=findViewById(R.id.etUserName);
        etPassword=findViewById(R.id.etPassWord);
        etPhoneNumber=findViewById(R.id.etPhoneNumber);
        etEmail=findViewById(R.id.etEmail);

        SharedPreferences saveInformation = getSharedPreferences(Const.SHARED_PREF_NAME_LOGIN,0);
        etUserName.setText(saveInformation.getString("userName",""));
        etPassword.setText(saveInformation.getString("password",""));
        etPhoneNumber.setText(saveInformation.getString("phoneNumber",""));
        etEmail.setText(saveInformation.getString("email",""));


        tamasbama.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(profile.this, tamasbama.class);
                startActivity(intent1);
            }
        });
        darbarema.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(profile.this, darbarema.class);
                startActivity(intent2);
            }
        });
        tanzimat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent3 = new Intent(profile.this, tanzimat.class);
                startActivity(intent3);
            }
        });
        download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent4 = new Intent(profile.this, download.class);
                startActivity(intent4);
            }
        });
        profile.setEnabled(false);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent6 = new Intent(profile.this,MainActivity.class);
                startActivity(intent6);
            }
        });

    }

    public void sabt(View view) {

        String userName = etUserName.getText().toString();
        String password=etPassword.getText().toString();
        String phoneNumber= etPhoneNumber.getText().toString();
        String email=etEmail.getText().toString();

        if (userName.length()<3){
            Toast.makeText(this, "نام کاربری باید حداقل شامل سه کاراکتر باشد", Toast.LENGTH_SHORT).show();
        }
        else if (phoneNumber.length() !=11 || !phoneNumber.startsWith("0")){
            Toast.makeText(this, "شماره تلفن وارد شده صحیح نمی باشد", Toast.LENGTH_SHORT).show();
        }
        else if (password.length()<8){
            Toast.makeText(this, "رمز عبور باید حداقل شامل هشت کاراکتر باشد", Toast.LENGTH_SHORT).show();
        }
        else {
            SharedPreferences sharedPreferences=getSharedPreferences(SHARED_PREF_NAME_LOGIN,MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean(Const.SHARED_PREF_KEY_AUTHENTICATION,true);
            editor.apply();

            SharedPreferences saveinformation = getSharedPreferences(SHARED_PREF_NAME_LOGIN,0);
            SharedPreferences.Editor editorsaveinformation = saveinformation.edit();

            editorsaveinformation.putString("userName",userName);
            editorsaveinformation.putString("password",password);
            editorsaveinformation.putString("phoneNumber",phoneNumber);
            editorsaveinformation.putString("email",email);

            editorsaveinformation.commit();

            final AlertDialog alertDialog;
            View alertDialogView =LayoutInflater.from(profile.this).inflate(R.layout.login_alert_dialog,null);

            AlertDialog.Builder builder=new AlertDialog.Builder(profile.this);
            builder.setView(alertDialogView);
            builder.setCancelable(false);
            alertDialog=builder.create();
            alertDialog.show();
            taeed=alertDialog.findViewById(R.id.taeed);

            taeed.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent=new Intent(profile.this,MainActivity.class);
                    startActivity(intent);

                }
            });


        }
    }


}
