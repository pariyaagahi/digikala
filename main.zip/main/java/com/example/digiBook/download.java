package com.example.digiBook;

import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;

import android.Manifest;
import android.app.DownloadManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;

import com.example.digiBook.adapter.musicAdapter;
import com.example.digiBook.database.musicsDbHelper;
import com.example.digiBook.entity.music;

import java.io.BufferedInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;

public class download extends BaseActivity {

    ListView musicListView;
    musicsDbHelper musicsDbHelper;
    EditText etsearch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_download);
        musicListView = findViewById(R.id.musicListView);
        musicsDbHelper = new musicsDbHelper(this);
        customActionBar();
        checkPermission();
        initMusicListView();
    }

    private void checkPermission() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 0);
        }
    }

    public void customActionBar() {
        View actionBarView = LayoutInflater.from(this).inflate(R.layout.actionbar_download, null);
        getSupportActionBar().setCustomView(actionBarView);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setTitle("");
        etsearch = actionBarView.findViewById(R.id.etsearch);
        etsearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                ArrayList<music> data = new musicsDbHelper(download.this).select(s.toString());
                musicAdapter musicAdapter = new musicAdapter(download.this, data);
                musicListView.setAdapter(musicAdapter);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

    }

    public void initMusicListView() {
        ArrayList<music> data = musicsDbHelper.select();
        musicAdapter adapter = new musicAdapter(this, data);
        musicListView.setAdapter(adapter);


        musicListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                music music = (music) parent.getItemAtPosition(position);
                new DownloadTask().execute(music.getMusicUrl());

            }
        });
    }

    private class DownloadTask extends AsyncTask<String, Integer, String> {

        ProgressDialog progressDialog;

        public DownloadTask() {
            progressDialog = new ProgressDialog(download.this);
            progressDialog.setTitle("موزیک");
            progressDialog.setMessage("در حال دانلود...");
            progressDialog.setMax(100);
            progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
            progressDialog.setCancelable(false);
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.setProgress(0);
            progressDialog.show();
        }

        @Override
        protected String doInBackground(String... params) {


            String Path = "/sdcard/download/song.mp3";

            String Url = params[0];

            try {
                URL url = new URL(Url);
                URLConnection connection = url.openConnection();
                int length = connection.getContentLength();
                connection.connect();

                InputStream inputStream = new BufferedInputStream(connection.getInputStream());
                OutputStream outputStream = new FileOutputStream(Path);

                byte[] buffer = new byte[1024];

                int count = -1;
                int total = 0;
                while ((count = inputStream.read(buffer)) != -1) {
                    total += count;
                    publishProgress(((total * 100) / length));
                    outputStream.write(buffer, 0, count);
                }
                outputStream.flush();
                outputStream.close();
                inputStream.close();
                showNotification();
                return "دانلود انجام شد";
            } catch (Exception e) {
                e.printStackTrace();
                Log.e("Download", e.getMessage());
                return "خطا در اتصال";
            }
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            progressDialog.setProgress(values[0]);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();
        }
    }

    public void showNotification() {
        NotificationManager manager = (NotificationManager) getSystemService(Service.NOTIFICATION_SERVICE);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this);
        builder.setContentTitle("دانلود موزیک با موفقیت انجام شد");
        builder.setSmallIcon(R.drawable.ic_baseline_music_note_24);
        Intent intent = new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS);

        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        builder.setContentIntent(pendingIntent);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            builder.setChannelId("chanelId");
            NotificationChannel channel = new NotificationChannel("chanelId", "name", NotificationManager.IMPORTANCE_DEFAULT);
            manager.createNotificationChannel(channel);
        }

        Notification notification = builder.build();
        manager.notify(1, notification);

    }

}