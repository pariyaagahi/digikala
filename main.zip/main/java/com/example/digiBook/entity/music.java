package com.example.digiBook.entity;

public class music {

    private String id;
    private String musicName;
    private String singer;
    private String imageUrl;
    private String musicUrl;

    public music(String id, String musicName, String singer, String imageUrl, String musicUrl) {
        this.id = id;
        this.musicName = musicName;
        this.singer = singer;
        this.imageUrl = imageUrl;
        this.musicUrl = musicUrl;
    }
    public music( String musicName, String singer, String imageUrl,String musicUrl) {
        this.musicName = musicName;
        this.singer = singer;
        this.imageUrl = imageUrl;
        this.musicUrl = musicUrl;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMusicName() {
        return musicName;
    }

    public void setMusicName(String musicName) {
        this.musicName = musicName;
    }

    public String getSinger() {
        return singer;
    }

    public void setSinger(String singer) {
        this.singer = singer;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getMusicUrl() {
        return musicUrl;
    }

    public void setMusicUrl(String musicUrl) {
        this.musicUrl = musicUrl;
    }
}
