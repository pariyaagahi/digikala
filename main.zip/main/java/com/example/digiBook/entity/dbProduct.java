package com.example.digiBook.entity;

public class dbProduct {

    private String id;
    private String title;
    private String cost;
    private String imageUrl;
    private String description;
    private String stars;

    public dbProduct(String id, String title, String cost ,String imageUrl,String description,String stars  ) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.cost = cost;
        this.imageUrl = imageUrl;
        this.stars=stars;
    }
    public dbProduct( String title,String cost, String imageUrl,String description,String stars ) {
        this.title = title;
        this.description = description;
        this.cost = cost;
        this.imageUrl = imageUrl;
        this.stars=stars;
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCost() {
        return cost;
    }

    public void setCost(String cost) {
        this.cost = cost;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getStars() {
        return stars;
    }

    public void setStars(String stars) {
        this.stars = stars;
    }
}



