package com.example.digiBook;

public class Const {

    public static final String ACTION_NAME="myAction";
    public static final String ACTION_WIFI="android.net.wifi.STATE_CHANGE";
    public static final String SHARED_PREF_NAME="setting";
    public static final String SHARED_PREF_KEY_THEME="theme";
    public static final String SHARED_PREF_KEY_AUTHENTICATION="authentication";
    public static final String SHARED_PREF_KEY_FONT="theme";
    public static final String SHARED_PREF_KEY_BOTH_THEMES="theme";
    public static final String SHARED_PREF_NAME_LOGIN="login";


}
