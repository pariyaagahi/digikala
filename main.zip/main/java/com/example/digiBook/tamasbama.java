package com.example.digiBook;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class tamasbama extends BaseActivity implements LocationListener {


    LocationManager locationManager;
    AlertDialog alertDialog;
    TextView tool, arz, ertefa;
    View tamasbama, darbarema, tanzimat, download, profile, home;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setTitle("LOCATION");
        setContentView(R.layout.activity_tamasbama);
        locationManager = (LocationManager) getSystemService(Service.LOCATION_SERVICE);
        Boolean statusGPS = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        showAlertDialog();
        if (!statusGPS) {
            alertDialog.show();
        }
        else {
            alertDialog.dismiss();
        }
        init();
    }

    public void showAlertDialog() {

        View alertDialogView = LayoutInflater.from(tamasbama.this).inflate(R.layout.customize_gps_alert_dialog, null);
        AlertDialog.Builder builder = new AlertDialog.Builder(tamasbama.this);
        builder.setView(alertDialogView);
        builder.setCancelable(true);
        alertDialog = builder.create();
        alertDialog.show();
        Button GPS = alertDialog.findViewById(R.id.GPS);
        GPS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(intent);
            }
        });
        alertDialog.dismiss();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 0);
            return;
        } else {
            requestLocationUpdate();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        locationManager.removeUpdates(this);
    }

    private void requestLocationUpdate() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            return;
        }
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 10f, this);
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == 0)
        {
            if(grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                requestLocationUpdate();
            }
        }
    }

    @Override
    public void onLocationChanged(@NonNull Location location) {
        double lng= location.getLongitude();
        double lat=location.getLatitude();
        double alt=location.getAltitude();

        tool.setText("طول جغرافیایی : " + lat );
        arz.setText("عرض جغرافیایی : "+ lng);
        ertefa.setText("ارتفاع : " + alt);

    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
    }

    @Override
    public void onProviderEnabled(@NonNull String provider) {
    }

    @Override
    public void onProviderDisabled(@NonNull String provider) {
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.setting_actionbar,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId()==R.id.action_back){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
    public void init() {

        tamasbama=findViewById(R.id.tamasBama);
        darbarema=findViewById(R.id.darbareMa);
        tanzimat=findViewById(R.id.tanzimat);
        download=findViewById(R.id.download);
        profile=findViewById(R.id.profile);
        home=findViewById(R.id.home);
        tool=findViewById(R.id.tool);
        arz=findViewById(R.id.arz);
        ertefa=findViewById(R.id.ertefa);


        tamasbama.setEnabled(false);
        darbarema.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(tamasbama.this, darbarema.class);
                startActivity(intent2);
            }
        });
        tanzimat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent3 = new Intent(tamasbama.this, tanzimat.class);
                startActivity(intent3);
            }
        });
        download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent4 = new Intent(tamasbama.this, download.class);
                startActivity(intent4);
            }
        });
        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent5 = new Intent(tamasbama.this, profile.class);
                startActivity(intent5);
            }
        });
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent6 = new Intent(tamasbama.this,MainActivity.class);
                startActivity(intent6);
            }
        });

    }


}