package com.example.digiBook;

import androidx.annotation.NonNull;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public class darbarema extends BaseActivity {

    View tamasbama, darbarema, tanzimat, download, profile, home;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().setTitle("ABOUT US");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_darbarema);
        init();
    }
    public void init() {

        tamasbama=findViewById(R.id.tamasBama);
        darbarema=findViewById(R.id.darbareMa);
        tanzimat=findViewById(R.id.tanzimat);
        download=findViewById(R.id.download);
        profile=findViewById(R.id.profile);
        home=findViewById(R.id.home);


        tamasbama.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(darbarema.this, tamasbama.class);
                startActivity(intent1);
            }
        });
        darbarema.setEnabled(false);
        tanzimat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent3 = new Intent(darbarema.this, tanzimat.class);
                startActivity(intent3);
            }
        });
        download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent4 = new Intent(darbarema.this, download.class);
                startActivity(intent4);
            }
        });
        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent5 = new Intent(darbarema.this, profile.class);
                startActivity(intent5);
            }
        });
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent6 = new Intent(darbarema.this,MainActivity.class);
                startActivity(intent6);
            }
        });

    }
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.setting_actionbar,menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId()==R.id.action_back){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

}