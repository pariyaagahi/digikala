package com.example.digiBook.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.Nullable;

import com.example.digiBook.entity.music;

import java.util.ArrayList;

public class musicsDbHelper extends dbHelper {

    public static final String MUSICS_TABLE_NAME = music.class.getSimpleName();
    public static final String MUSICS_KET_ID = "id";
    public static final String musicName="musicName";
    public static final String singer="singer";
    public static final String imageUrl="imageUrl";
    public static final String musicUrl="musicUrl";


    public musicsDbHelper(@Nullable Context context) {
        super(context);
    }

    public long insert(music music) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(musicName, music.getMusicName());
        contentValues.put(singer, music.getSinger());
        contentValues.put(imageUrl, music.getImageUrl());
        contentValues.put(musicUrl,music.getMusicUrl());

        return db.insert(MUSICS_TABLE_NAME, null, contentValues);
    }


    public ArrayList<music> select() {
        ArrayList<music> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String[] columns = {MUSICS_KET_ID, musicName, singer,imageUrl,musicUrl};
        Cursor cursor = db.query(MUSICS_TABLE_NAME, columns, null, null, null, null, null);
        if (cursor.getCount() > 0) {
            while (cursor.moveToNext()) {
                String musicNamee = cursor.getString(cursor.getColumnIndex(musicName));
                String singerr = cursor.getString(cursor.getColumnIndex(singer));
                String imageUrll = cursor.getString(cursor.getColumnIndex(imageUrl));
                String musicUrll=cursor.getString(cursor.getColumnIndex(musicUrl));

                music music = new music(musicNamee,singerr, imageUrll,musicUrll);
                list.add(music);
            }

        }
        cursor.close();
        return list;
    }
    public ArrayList<music> select(String searchValue) {
        ArrayList<music> list = new ArrayList<>();


        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {MUSICS_KET_ID, musicName, singer,imageUrl,musicUrl};
        Cursor cursor = db.query(MUSICS_TABLE_NAME, columns, "musicName like ?", new String[]{"%" + searchValue + "%"}, null, null, null);
        if (cursor.getCount() > 0) {
            while (cursor.moveToNext()) {
                String musicNamee = cursor.getString(cursor.getColumnIndex(musicName));
                String singerr = cursor.getString(cursor.getColumnIndex(singer));
                String imageUrll = cursor.getString(cursor.getColumnIndex(imageUrl));
                String musicUrll=cursor.getString(cursor.getColumnIndex(musicUrl));

                music music = new music(musicNamee,singerr, imageUrll,musicUrll);
                list.add(music);

            }
        }

        cursor.close();

        return list;

    }
}
