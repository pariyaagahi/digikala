package com.example.digiBook.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.Nullable;

import com.example.digiBook.entity.dbProduct;

import java.util.ArrayList;

public class productsDbHelper extends dbHelper {

    public static final String PRODUCTS_TABLE_NAME = dbProduct.class.getSimpleName();
    public static final String PRODUCTS_KET_ID = "id";
    public static final String title="title";
    public static final String cost="cost";
    public static final String imageUrl="imageUrl";
    public static final String description="description";
    public static final String STARS="stars";





    public productsDbHelper(@Nullable Context context) {
        super(context);
    }

    public long insert(dbProduct product) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(PRODUCTS_KET_ID,product.getId());
        contentValues.put(title, product.getTitle());
        contentValues.put(description, product.getDescription());
        contentValues.put(cost, product.getCost());
        contentValues.put(imageUrl, product.getImageUrl());
        contentValues.put(STARS,product.getStars());

        return db.insert(PRODUCTS_TABLE_NAME, null, contentValues);
    }
    public ArrayList<dbProduct> select() {

        ArrayList<dbProduct> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String[] columns = {PRODUCTS_KET_ID, title, cost,imageUrl,description,STARS};
        Cursor cursor = db.query(PRODUCTS_TABLE_NAME, columns, null, null, null, null, null);
        if (cursor.getCount() > 0) {
            while (cursor.moveToNext()) {
                String productId=cursor.getString(cursor.getColumnIndex(PRODUCTS_KET_ID));
                String productTitle = cursor.getString(cursor.getColumnIndex(title));
                String productCost = cursor.getString(cursor.getColumnIndex(cost));
                String productImageUrl = cursor.getString(cursor.getColumnIndex(imageUrl));
                String productDescription = cursor.getString(cursor.getColumnIndex(description));
                String productStars = cursor.getString(cursor.getColumnIndex(STARS));



                dbProduct product = new dbProduct(productId,productTitle,productCost, productImageUrl,productDescription,productStars);
                list.add(product);
            }

        }
        cursor.close();
        return list;
    }

    public ArrayList<dbProduct> select(String searchValue) {
        ArrayList<dbProduct> list = new ArrayList<>();


        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {PRODUCTS_KET_ID, title, cost,imageUrl,description,STARS};
        Cursor cursor = db.query(PRODUCTS_TABLE_NAME, columns, "title like ?", new String[]{"%" + searchValue + "%"}, null, null, null);
        if (cursor.getCount() > 0) {
            while (cursor.moveToNext()) {
                String productId=cursor.getString(cursor.getColumnIndex(PRODUCTS_KET_ID));
                String productTitle = cursor.getString(cursor.getColumnIndex(title));
                String productCost = cursor.getString(cursor.getColumnIndex(cost));
                String productImageUrl = cursor.getString(cursor.getColumnIndex(imageUrl));
                String productDescription = cursor.getString(cursor.getColumnIndex(description));
                String productStars=cursor.getString(cursor.getColumnIndex(STARS));

                dbProduct product = new dbProduct(productId,productTitle,productCost, productImageUrl,productDescription,productStars);
                list.add(product);

            }
        }

        cursor.close();

        return list;

    }
    public boolean checkEmptyDB(){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor cursor= db.rawQuery("SELECT * FROM " + PRODUCTS_TABLE_NAME, null );
        Boolean rowExists;
        if (cursor.moveToFirst()){
            rowExists=true;
        }
        else {
            rowExists=false;
        }
        return rowExists;
    }

    public Boolean updateStars(String id,String stars){
        SQLiteDatabase db= this.getWritableDatabase();
        ContentValues contentValues= new ContentValues();
        contentValues.put( PRODUCTS_KET_ID ,id);
        contentValues.put(STARS,stars);
        return  db.update(PRODUCTS_TABLE_NAME,contentValues,PRODUCTS_KET_ID+"="+id,null)>0;


    }

}
