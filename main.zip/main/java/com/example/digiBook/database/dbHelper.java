package com.example.digiBook.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class dbHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "DB.product";
    private static final int VERSION = 8;

    public dbHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        createTable(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        createTable(db);
    }

    private void createTable(SQLiteDatabase db) {

        String query = "create table IF NOT EXISTS " + productsDbHelper.PRODUCTS_TABLE_NAME + " (" +
                productsDbHelper.PRODUCTS_KET_ID + " varchar(100) primary key , " +
                productsDbHelper.title + " varchar(100) , " +
                productsDbHelper.cost + " varchar(100) , " +
                productsDbHelper.imageUrl + " varchar(100) , " +
                productsDbHelper.description + " varchar(100) , " +
                productsDbHelper.STARS + " varchar(100) " +
                ")";

        db.execSQL(query);

        query = "create table IF NOT EXISTS " + musicsDbHelper.MUSICS_TABLE_NAME + " (" +
                musicsDbHelper.MUSICS_KET_ID + " varchar(100) primary key , " +
                musicsDbHelper.musicName + " varchar(100) , " +
                musicsDbHelper.singer + " varchar(100) , " +
                musicsDbHelper.imageUrl + " varchar(100)  , " +
                musicsDbHelper.musicUrl + " varchar(100) " +
                ")";

        db.execSQL(query);



    }
}