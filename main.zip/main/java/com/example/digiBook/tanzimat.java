package com.example.digiBook;

import androidx.annotation.NonNull;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;

public class tanzimat extends BaseActivity {

    View tamasbama, darbarema, tanzimat, download, profile, home;
    public static int ThemeValue = R.style.AppTheme;
    Switch switch1, switch2;
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(ThemeValue);
        super.onCreate(savedInstanceState);
        getSupportActionBar().setTitle("SETTING");
        setContentView(R.layout.activity_tanzimat);
        init();

    }


    private void setCustomFont(int font) {
        SharedPreferences sharedPreferences = getSharedPreferences(Const.SHARED_PREF_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(Const.SHARED_PREF_KEY_FONT, font);
        editor.apply();
    }

    private void setCustomTheme(int theme) {
        SharedPreferences sharedPreferences = getSharedPreferences(Const.SHARED_PREF_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(Const.SHARED_PREF_KEY_THEME, theme);
        editor.apply();
    }
    private void setCustomBothThemes(int theme) {
        SharedPreferences sharedPreferences = getSharedPreferences(Const.SHARED_PREF_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(Const.SHARED_PREF_KEY_BOTH_THEMES, theme);
        editor.apply();
    }

    private void refresh() {
        finish();
        startActivity(getIntent());
    }

    public void init() {

        tamasbama = findViewById(R.id.tamasBama);
        darbarema = findViewById(R.id.darbareMa);
        tanzimat = findViewById(R.id.tanzimat);
        download = findViewById(R.id.download);
        profile = findViewById(R.id.profile);
        home = findViewById(R.id.home);
        switch1 = findViewById(R.id.switch1);
        switch2 = findViewById(R.id.switch2);
        btn = findViewById(R.id.btn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (switch1.isChecked()) {
                    ThemeValue = R.style.myStyle;
                    setCustomTheme(R.style.myStyle);
                    refresh();
                } else {
                    ThemeValue = R.style.AppTheme;
                    setCustomTheme(R.style.AppTheme);
                    refresh();
                }
                if (switch2.isChecked()){
                    ThemeValue = R.style.fontStyle;
                    setCustomFont(R.style.fontStyle);
                    refresh();
                }
                if(switch1.isChecked() && switch2.isChecked()){
                    ThemeValue=R.style.bothStyle;
                    setCustomBothThemes(R.style.bothStyle);
                    refresh();

                }

            }
        });
        
        tamasbama.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(tanzimat.this, tamasbama.class);
                startActivity(intent1);
            }
        });
        darbarema.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(tanzimat.this, darbarema.class);
                startActivity(intent2);
            }
        });
        tanzimat.setEnabled(false);
        download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent4 = new Intent(tanzimat.this, download.class);
                startActivity(intent4);
            }
        });
        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent5 = new Intent(tanzimat.this, profile.class);
                startActivity(intent5);
            }
        });
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent6 = new Intent(tanzimat.this, MainActivity.class);
                startActivity(intent6);
            }
        });

    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.setting_actionbar, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == R.id.action_back) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

}