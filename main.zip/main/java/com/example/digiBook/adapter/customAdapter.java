package com.example.digiBook.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.digiBook.R;
import com.example.digiBook.entity.dbProduct;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class customAdapter extends BaseAdapter {

    private  Context context;
    private ArrayList<dbProduct> list;
    private int layout;

    public customAdapter(Context context, ArrayList<dbProduct> list, int layout) {
        this.context = context;
        this.list = list;
        this.layout=layout;
    }


    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position , View view, ViewGroup viewGroup) {

        if (view == null){
            view= LayoutInflater.from(this.context).inflate(layout,null);
        }
        dbProduct product=this.list.get(position);

        TextView productName=view.findViewById(R.id.tvProductName);
        TextView productCost=view.findViewById(R.id.tvProductCost);
        TextView productDescription=view.findViewById(R.id.tvProductDescription);
        ImageView productImage=view.findViewById(R.id.productImage);



        productName.setText(String.valueOf(product.getTitle()));
        productCost.setText(String.valueOf(product.getCost()));
        productDescription.setText(String.valueOf(product.getDescription()));

        Picasso.get().load(product.getImageUrl())
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder).into(productImage);

        return view;


    }

    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }

    public ArrayList<dbProduct> getList() {
        return list;
    }

    public void setList(ArrayList<dbProduct> list) {
        this.list = list;
    }

    public int getLayout() {
        return layout;
    }

    public void setLayout(int layout) {
        this.layout = layout;
    }
}
