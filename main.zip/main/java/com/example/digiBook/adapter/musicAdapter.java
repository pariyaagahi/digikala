package com.example.digiBook.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;


import com.example.digiBook.R;
import com.example.digiBook.entity.music;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class musicAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<music> list;

    public musicAdapter(Context context, ArrayList<music> list) {
        this.context = context;
        this.list = list;
    }



    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup){

     if (view==null){
        view= LayoutInflater.from(this.context).inflate(R.layout.music_item,null);
    }
    music music=this.list.get(position);

    TextView musicName=view.findViewById(R.id.tvMusicName);
    TextView singer=view.findViewById(R.id.tvSinger);
    ImageView imageUrl=view.findViewById(R.id.musicImage);


        musicName.setText(String.valueOf(music.getMusicName()));
        singer.setText(String.valueOf(music.getSinger()));
        Picasso.get().load(music.getImageUrl())
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder).into(imageUrl);
        return view;

    }
}
